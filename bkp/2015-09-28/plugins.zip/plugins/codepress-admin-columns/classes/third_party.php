<?php
require_once CPAC_DIR . 'classes/third_party/all-in-seo.php';
require_once CPAC_DIR . 'classes/third_party/bbpress.php';
require_once CPAC_DIR . 'classes/third_party/ninja_forms.php';
require_once CPAC_DIR . 'classes/third_party/wpml.php';
require_once CPAC_DIR . 'classes/third_party/yoast_seo.php';